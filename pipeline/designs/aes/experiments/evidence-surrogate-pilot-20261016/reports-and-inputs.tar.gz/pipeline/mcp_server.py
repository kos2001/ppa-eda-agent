#!/usr/bin/env python3
"""Dependency-free MCP stdio server exposing this pipeline's real
operations to agents — pattern ported from
github.com/kos2001/strongarm-sizing-console's mcp_server.py (a sibling
analog-IC console that does the same "give agents first-class tools
instead of shelled-out commands" thing for its own ngspice pipeline).
Same protocol shape (JSON-RPC 2.0 over stdio, initialize/tools/list/
tools/call), same "no third-party packages" constraint, adapted to call
this repo's own pipeline modules directly (not proxied over HTTP to a
running backend, since this pipeline has no always-on server process —
each tool call runs a real OpenLane/orchestrator/review operation
in-process).

Register with Claude Code (or hermes-agent's api_server) as an MCP
server pointed at this file; see README.md's "MCP server" section.
Within a Claude Code session already working in this repo, a subagent
can just call these Python modules directly via Bash — this server
exists for contexts that want a typed tool boundary instead (a future
session, a non-Claude-Code agent, hermes-agent).
"""
import base64
import json
import os
import re
import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import analog_loop  # noqa: E402
import custom_bridge  # noqa: E402
import gate_schematic  # noqa: E402
import stdcell_schematic  # noqa: E402
import stdcell_signoff  # noqa: E402
import stdcell_survey  # noqa: E402
import equiv_check  # noqa: E402
import odb_query  # noqa: E402
import sta_path  # noqa: E402
import orchestrator  # noqa: E402
import render_layout  # noqa: E402
import request_review  # noqa: E402
import run_stage  # noqa: E402
import self_improve  # noqa: E402
import sta_report  # noqa: E402
import tech_compare  # noqa: E402
import verify_diagnosis  # noqa: E402

PROTOCOL_VERSION = "2024-11-05"
REPO_ROOT = Path(__file__).resolve().parent.parent

TOOLS = [
    {
        "name": "ppa_run_stage",
        "description": "Runs ONE real OpenLane candidate for a design (placement/"
                        "routing/signoff through the full flow, or a real OpenLane "
                        "run failure) and returns its real metrics.json. This is a "
                        "single real Docker+OpenLane run — expect it to take "
                        "roughly a minute or more, not an instant call.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag"],
            "properties": {
                "design": {"type": "string", "description": "e.g. 'counter4' — must exist under pipeline/designs/"},
                "tag": {"type": "string", "description": "run tag (becomes runs/<tag>/)"},
                "overrides": {
                    "type": "object",
                    "description": "OpenLane config overrides, e.g. {\"FP_CORE_UTIL\": 35}",
                },
            },
        },
    },
    {
        "name": "ppa_orchestrate",
        "description": "Runs the full real candidate-generation-and-auto-repair "
                        "loop for a design (pipeline/orchestrator.py) against its "
                        "run_spec.json, writing a real reference-db case. Can "
                        "involve several real OpenLane runs — expect minutes, not "
                        "seconds.",
        "inputSchema": {
            "type": "object",
            "required": ["design"],
            "properties": {
                "design": {"type": "string"},
                "max_parallel": {"type": "integer", "default": 1},
                "max_iterations": {"type": "integer"},
            },
        },
    },
    {
        "name": "ppa_get_case",
        "description": "Reads the latest real reference-db case for a design "
                        "(read-only, fast — no new run). Returns the same JSON "
                        "the dashboard's Layout Pipeline tab renders.",
        "inputSchema": {
            "type": "object",
            "required": ["design"],
            "properties": {"design": {"type": "string"}},
        },
    },
    {
        "name": "ppa_self_improve_scan",
        "description": "Runs pipeline/self_improve.py's scan: real auto-repair "
                        "coverage per design, auto-generates review requests for "
                        "any OPEN case with no review yet, and flags "
                        "pattern-promotion candidates.",
        "inputSchema": {
            "type": "object",
            "properties": {"design": {"type": "string", "description": "omit to scan all designs"}},
        },
    },
    {
        "name": "ppa_request_review",
        "description": "Generates a human-in-the-loop review request for a "
                        "design's latest OPEN case (pipeline/request_review.py "
                        "request) — names the relevant subagents and includes the "
                        "existing diagnosis. Does not dispatch the subagent "
                        "itself; the caller does that next, then calls "
                        "ppa_apply_review with the result.",
        "inputSchema": {
            "type": "object",
            "required": ["design"],
            "properties": {"design": {"type": "string"}},
        },
    },
    {
        "name": "ppa_apply_review",
        "description": "Applies a subagent's real review response back into a "
                        "design's reference-db case (pipeline/request_review.py "
                        "apply) — appends to the diagnosis field and the "
                        "human_in_the_loop history, via json.dump only.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "agent", "response_text"],
            "properties": {
                "design": {"type": "string"},
                "agent": {"type": "string", "description": "e.g. 'feedback-optimizer'"},
                "response_text": {"type": "string"},
            },
        },
    },
    {
        "name": "ppa_render_layout",
        "description": "Renders a real PNG of a completed run's actual GDS layout "
                        "via KLayout (bundled in the OpenLane Docker image already "
                        "used, no new dependency) — view the returned file with the "
                        "Read tool afterward. Applies arxiv.org/html/2605.06936v3's "
                        "finding that layout images measurably improve DRC-fixing "
                        "accuracy over text-only diagnosis.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag", "output"],
            "properties": {
                "design": {"type": "string"},
                "tag": {"type": "string", "description": "run tag under designs/<design>/runs/"},
                "output": {"type": "string", "description": "where to write the PNG"},
                "size": {"type": "integer", "default": 900},
            },
        },
    },
    {
        "name": "ppa_verify_diagnosis",
        "description": "Cross-checks a design's latest case diagnosis prose "
                        "against that case's own recorded data, flagging EDA "
                        "error codes and candidate tags it cites that the run "
                        "never actually produced. Groundedness only — it does "
                        "NOT judge whether the diagnosis is correct.",
        "inputSchema": {
            "type": "object",
            "required": ["design"],
            "properties": {"design": {"type": "string"}},
        },
    },
    {
        "name": "ppa_equiv_check",
        "description": "Proves a run's synthesized netlist is functionally "
                        "equivalent to its RTL using Yosys SAT equivalence "
                        "(~1s). Fills the gap DRC/LVS/timing leave open: LVS "
                        "compares layout against netlist, nothing compared "
                        "netlist against RTL, so a clean-but-wrong synthesis "
                        "result would otherwise pass.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag"],
            "properties": {"design": {"type": "string"}, "tag": {"type": "string"}},
        },
    },
    {
        "name": "ppa_sta_report",
        "description": "Reads the OpenSTA analysis a run already produced — the "
                        "real critical path stage by stage (which cell, how much "
                        "delay, what share of arrival) and the max_slew/max_cap/"
                        "max_fanout violators. Fast, read-only, no re-run: turns "
                        "'worst setup WNS -0.05' into which path and which cell.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag"],
            "properties": {
                "design": {"type": "string"}, "tag": {"type": "string"},
                "corner": {"type": "string", "description": "omit for all corners"},
            },
        },
    },
    {
        "name": "ppa_sta_path",
        "description": "Traces slew and delay STAGE BY STAGE along the path to one "
                        "chosen pin, by running a fresh report_checks. This is the "
                        "question no stored report answers: ppa_sta_report says WHICH "
                        "pins violate, this says WHY a given one does — which cell in "
                        "the chain adds the slew. It found that OpenROAD was repairing "
                        "a macro's slew violation with delay cells, after five config "
                        "variables had been tried and all were null. Note the path is "
                        "usually NOT the critical path (that case had +18.57ns setup "
                        "slack), so take the pin from ppa_sta_report's max-slew "
                        "violator list rather than from the timing report.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag", "pin"],
            "properties": {
                "design": {"type": "string"}, "tag": {"type": "string"},
                "pin": {"type": "string",
                        "description": "endpoint, e.g. 'u_sram/addr0[3]'"},
                "corner": {"type": "string", "description": "default tt_025C_1v80"},
            },
        },
    },
    {
        "name": "ppa_sta_query",
        "description": "Runs a read-only OpenSTA reporting command against a "
                        "completed run — report_checks, report_power, "
                        "report_check_types, get_property and the rest. Use it "
                        "for the question nobody shipped a tool for: this "
                        "pipeline's own breakthrough on sram_wrapper was "
                        "`report_checks -to <pin>`, which existed in no tool "
                        "until it was added as one. Commands that modify "
                        "anything are refused with the list of what is allowed.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag", "tcl"],
            "properties": {
                "design": {"type": "string"}, "tag": {"type": "string"},
                "tcl": {"type": "string",
                        "description": "one or more read-only report/get commands"},
                "corner": {"type": "string", "description": "default tt_025C_1v80"},
            },
        },
    },
    {
        "name": "ppa_odb_query",
        "description": "Queries a run's real OpenROAD database (.odb) directly for "
                        "measured per-net placement facts — pin count, HPWL and max "
                        "span in microns. Answers questions about ONE specific net "
                        "that OpenLane's aggregate metrics.json cannot, e.g. whether "
                        "a driver actually landed adjacent to a macro pin. Read-only "
                        "and fast; needs a run that reached floorplan or later.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "tag"],
            "properties": {
                "design": {"type": "string"},
                "tag": {"type": "string"},
                "net_filter": {"type": "string", "description": "regex on net name"},
            },
        },
    },
    {
        "name": "ppa_tech_compare",
        "description": "Runs the SAME design through two or more standard-cell "
                        "technologies (real full OpenLane runs, one per variant, "
                        "so expect minutes each) and returns a real PPA delta "
                        "with the design invariants held fixed — the technology "
                        "half of the design/technology trade-off. A variant that fails to build is reported "
                        "as a real finding, not dropped.",
        "inputSchema": {
            "type": "object",
            "required": ["design", "variants"],
            "properties": {
                "design": {"type": "string"},
                "variants": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "standard-cell libraries, e.g. "
                                    "[\"sky130_fd_sc_hd\", \"sky130_fd_sc_hs\"]; "
                                    "the first is the baseline",
                },
            },
        },
    },
    {
        "name": "ppa_custom_status",
        "description": "What of the open-source Virtuoso-equivalent stack "
                        "(xschem / magic / klayout / ngspice / netgen) this host "
                        "can actually run, each mapped to the Cadence tool it "
                        "stands in for. Read this BEFORE ppa_custom_eval or "
                        "ppa_spice_sim: a backend that is not installed returns a "
                        "not_installed error, and knowing that first is cheaper "
                        "than discovering it mid-flow.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "docker": {"type": "boolean",
                            "description": "also ask the pinned OpenLane image, "
                                           "which carries magic/klayout/netgen "
                                           "(slow: pulls/starts a container)"},
            },
        },
    },
    {
        "name": "ppa_custom_eval",
        "description": "Runs a script in ONE open-source custom-design backend's "
                        "own batch language — the counterpart of executing SKILL "
                        "in Virtuoso, except the stack is five programs and three "
                        "languages so the backend is explicit: xschem/magic/netgen "
                        "take Tcl, klayout takes Python, ngspice takes a deck with "
                        "a .control block. Exit code alone is NOT a verdict for "
                        "these tools; read the returned status (partial means the "
                        "tool finished and still dropped a result).",
        "inputSchema": {
            "type": "object",
            "required": ["backend", "code"],
            "properties": {
                "backend": {"type": "string",
                             "enum": ["xschem", "magic", "klayout", "ngspice",
                                      "netgen"]},
                "code": {"type": "string"},
                "timeout": {"type": "integer"},
            },
        },
    },
    {
        "name": "ppa_netlist_schematic",
        "description": "Netlists a schematic with xschem — the ENTRY POINT of the "
                        "custom/analog flow, and the tool to reach for before "
                        "ppa_spice_sim. The schematic is the source; the deck is a "
                        "build artifact, and a hand-written deck silently loses the "
                        "diffusion parasitics the PDK's own symbols attach to every "
                        "device (measured: ~3% on inverter delay, identical DC trip "
                        "point). Returns the generated .spice path, which still "
                        "carries %PDK_LIB% so ppa_spice_sim can bind any corner.",
        "inputSchema": {
            "type": "object",
            "required": ["schematic"],
            "properties": {
                "schematic": {"type": "string",
                               "description": "path to a .sch, e.g. "
                                              "pipeline/analog/inv/inv_tb.sch"},
                "pdk": {"type": "string", "description": "default sky130A"},
                "out_dir": {"type": "string",
                             "description": "default: beside the schematic"},
                "timeout": {"type": "integer"},
            },
        },
    },
    {
        "name": "ppa_analog_loop",
        "description": "Runs the custom/analog closed loop for a design under "
                        "pipeline/analog/: sizes proposed, measured at every "
                        "corner the spec names, scored, and repaired from the "
                        "violation's own numbers until something passes or the "
                        "patterns run out. Minutes, not seconds — each candidate "
                        "is a real ngspice run per corner. Writes a case to "
                        "reference-db/analog/.",
        "inputSchema": {
            "type": "object",
            "required": ["design"],
            "properties": {
                "design": {"type": "string",
                            "description": "directory under pipeline/analog/, "
                                           "e.g. \"inv\""},
                "max_iterations": {"type": "integer"},
            },
        },
    },
    {
        "name": "ppa_analog_scan",
        "description": "Where every analog design stands: real auto-repair "
                        "coverage, whether the latest case passed or is OPEN, and "
                        "the concrete next step — which distinguishes 'ran out of "
                        "iteration budget' (re-run with more) from 'no pattern "
                        "matched' (needs a human). Read-only, no runs.",
        "inputSchema": {
            "type": "object",
            "properties": {"design": {"type": "string"}},
        },
    },
    {
        "name": "ppa_gate_schematic",
        "description": "Draws what the layout pipeline actually built: converts a "
                        "design's real synthesis netlist into an xschem schematic "
                        "using the PDK's own importer and its 440 sky130_fd_sc_hd "
                        "symbols. This is the view a layout render cannot give — "
                        "which cells, and what is connected to what. Caps at 1,500 "
                        "cells because past that the drawing is real and unreadable "
                        "(aes: 11,616 cells, 39 MB of SVG); pass force to override. "
                        "A run built with another standard-cell library is reported, "
                        "not drawn wrong.",
        "inputSchema": {
            "type": "object",
            "required": ["design"],
            "properties": {
                "design": {"type": "string",
                            "description": "directory under pipeline/designs/"},
                "run_dir": {"type": "string",
                             "description": "a specific run; default is the newest "
                                            "with a drawable netlist"},
                "draw": {"type": "boolean", "description": "also render an SVG"},
                "force": {"type": "boolean"},
                "seed": {"type": "string",
                          "description": "a net or instance to draw a CONE around "
                                         "instead of the whole design — this is "
                                         "how aes (11,616 cells) and riscv32i "
                                         "(5,423) get looked at"},
                "depth": {"type": "integer", "description": "cone depth, default 4"},
                "direction": {"type": "string",
                               "enum": ["fanin", "fanout", "both"],
                               "description": "default fanin"},
            },
        },
    },
    {
        "name": "ppa_stdcell_schematic",
        "description": "Opens a sky130_fd_sc_hd standard cell and draws its "
                        "TRANSISTORS, from the foundry's own CDL via the PDK's "
                        "SPICE importer — the descend-into-the-cell move, and the "
                        "answer to 'what is an a21oi_2' that a gate-level box "
                        "cannot give. Omit `cell` to list the library (optionally "
                        "filtered by `q`). 370 of 437 cells draw; the sequential "
                        "ones use devices with no xschem symbol and are refused by "
                        "name rather than drawn three transistors short.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "cell": {"type": "string",
                          "description": "e.g. sky130_fd_sc_hd__nand2_1"},
                "q": {"type": "string", "description": "substring filter when listing"},
                "draw": {"type": "boolean", "description": "also render an SVG"},
            },
        },
    },
    {
        "name": "ppa_stdcell_signoff",
        "description": "Runs the layout half of a standard cell: Magic DRC on the "
                        "PDK's real .mag, Magic extraction, and netgen LVS against "
                        "the schematic derived from the foundry CDL — then records "
                        "a case in reference-db/stdcells/. A pass is also evidence "
                        "that the CDL-to-SPICE translation behind the schematic "
                        "view preserves the circuit, which nothing else checks. "
                        "Omit `cell` for a scan of what the store holds.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "cell": {"type": "string",
                          "description": "e.g. sky130_fd_sc_hd__nand2_1"},
                "no_case": {"type": "boolean",
                             "description": "run without writing to the store"},
            },
        },
    },
    {
        "name": "ppa_stdcell_survey",
        "description": "Reads the standard-cell signoff store back and says what "
                        "it found: how many cells are clean, which have real DRC "
                        "errors and under which rule, which LVS mismatches are real "
                        "against which are cells with no transistors, and the shape "
                        "of each mismatch (how many devices and nets the layout "
                        "carries that the schematic does not). Read-only — it "
                        "re-runs nothing.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ppa_render_schematic",
        "description": "Draws a schematic as SVG using xschem's own renderer — "
                        "the custom half's counterpart of ppa_render_layout. Use "
                        "it to SEE the circuit a netlist came from; the drawing "
                        "and the netlist are generated from the same .sch, so it "
                        "cannot disagree with what was simulated.",
        "inputSchema": {
            "type": "object",
            "required": ["schematic"],
            "properties": {
                "schematic": {"type": "string",
                               "description": "path to a .sch, e.g. "
                                              "pipeline/analog/inv/inv_tb.sch"},
                "pdk": {"type": "string", "description": "default sky130A"},
                "out": {"type": "string",
                         "description": "default: beside the schematic, .svg"},
                "timeout": {"type": "integer"},
            },
        },
    },
    {
        "name": "ppa_spice_sim",
        "description": "A real transistor-level simulation of a SPICE deck against "
                        "the PDK's own device models (ngspice), returning the "
                        "parsed .meas values — the analog counterpart of "
                        "ppa_sta_report, and the only path in this pipeline to a "
                        "number that is not standard-cell. A deck containing the "
                        "token %PDK_LIB% is bound to the requested PDK and corner "
                        "(gf180mcu's typical section is named `typical`, not "
                        "`tt` — that is why binding is not left to the caller).",
        "inputSchema": {
            "type": "object",
            "required": ["netlist"],
            "properties": {
                "netlist": {"type": "string",
                             "description": "path to a .spice deck, e.g. "
                                            "pipeline/analog/inv/inv.spice"},
                "pdk": {"type": "string", "description": "default sky130A"},
                "corner": {"type": "string",
                            "description": "tt/ss/ff/sf/fs (default tt)"},
                "timeout": {"type": "integer"},
            },
        },
    },
]


def _tool_run_stage(args: dict) -> dict:
    design_dir = REPO_ROOT / "pipeline" / "designs" / args["design"]
    overrides = [f"{k}={orchestrator.override_value(v)}" for k, v in args.get("overrides", {}).items()]
    run_dir = run_stage.run_stage(design_dir, args["tag"], to_step=None, overrides=overrides)
    return {"run_dir": str(run_dir), "metrics": run_stage.read_metrics(run_dir)}


def _tool_orchestrate(args: dict) -> dict:
    # Delegates to orchestrator.orchestrate() instead of re-implementing
    # the iterate/repair loop here — this file used to duplicate it, and
    # the duplicate had actually drifted: it collapsed the "winner found"
    # and "max_iterations reached" exits into one untagged branch (`if
    # winner or iteration >= max_iterations: break`), silently losing the
    # distinction orchestrator.py's own loop preserves. One real
    # total-guarded implementation, called from both places, so this
    # can't happen again (see orchestrator.py's STOP_REASONS /
    # "Graph engineering" doc section).
    design_dir = REPO_ROOT / "pipeline" / "designs" / args["design"]
    run_spec_path = design_dir / "run_spec.json"
    run_spec = json.loads(run_spec_path.read_text(encoding="utf-8"))
    design_name = run_spec.get("design_name", args["design"])
    max_iterations = (args["max_iterations"] if args.get("max_iterations") is not None
                      else run_spec.get("max_iterations", 3))
    max_parallel = max(1, args.get("max_parallel", 1))
    search_plan = orchestrator.validate_run_plan(run_spec, max_iterations)

    all_iterations, winner, stop_reason, exploration = orchestrator.orchestrate(
        design_dir, run_spec, max_iterations, max_parallel
    )

    case_file = orchestrator.write_case(
        design_name, design_dir, all_iterations, winner, stop_reason,
        exploration=exploration, search_plan=search_plan)
    return {
        "winner_tag": winner["tag"] if winner else None,
        "iterations_run": len(all_iterations),
        "stop_reason": stop_reason,
        "case_file": str(case_file),
    }


def _tool_get_case(args: dict) -> dict:
    # Light, like the dashboard list this mirrors: the full aes case is
    # 56 MB of layout geometry, which is no use in a model's context.
    _case_file, case = request_review.latest_case(args["design"], light=True)
    return case


def _tool_self_improve_scan(args: dict) -> dict:
    designs = [args["design"]] if args.get("design") else sorted(
        d.name for d in self_improve.DESIGNS_DIR.iterdir() if d.is_dir()
    )
    return {d: self_improve.scan_design(d) for d in designs}


def _tool_request_review(args: dict) -> dict:
    ns = SimpleNamespace(design=args["design"])
    request_review.cmd_request(ns)
    out_file = request_review.REFDB / "reviews"
    # cmd_request prints the path; re-derive it the same way rather than
    # parse stdout, since latest_case() + the same date is exactly how it
    # names the file.
    case_file, case = request_review.latest_case(args["design"], light=True)
    review_file = out_file / f"{args['design']}__{case['date']}__request.md"
    return {"review_request_file": str(review_file),
            "content": review_file.read_text(encoding="utf-8") if review_file.exists() else None}


def _tool_apply_review(args: dict) -> dict:
    tmp_path = REPO_ROOT / "pipeline" / f".mcp_review_response_{os.getpid()}.txt"
    tmp_path.write_text(args["response_text"], encoding="utf-8")
    try:
        ns = SimpleNamespace(design=args["design"], agent=args["agent"], response_file=tmp_path)
        request_review.cmd_apply(ns)
    finally:
        tmp_path.unlink(missing_ok=True)
    case_file, case = request_review.latest_case(args["design"], light=True)
    return {"case_file": str(case_file), "human_in_the_loop": case.get("human_in_the_loop")}


def _tool_render_layout(args: dict) -> dict:
    run_dir = REPO_ROOT / "pipeline" / "designs" / args["design"] / "runs" / args["tag"]
    output_path = Path(args["output"])
    out = render_layout.render_gds_png(run_dir, output_path, args.get("size", 900))
    return {"png_path": str(out)}


def _tool_verify_diagnosis(args: dict) -> dict:
    _case_file, case = request_review.latest_case(args["design"], light=True)
    return verify_diagnosis.verify_case(case)


def _tool_equiv_check(args: dict) -> dict:
    design_dir = REPO_ROOT / "pipeline" / "designs" / args["design"]
    run_dir = design_dir / "runs" / args["tag"]
    return equiv_check.check(design_dir, run_dir)


def _tool_sta_report(args: dict) -> dict:
    run_dir = REPO_ROOT / "pipeline" / "designs" / args["design"] / "runs" / args["tag"]
    return sta_report.read_run(run_dir, args.get("corner"))


def _tool_sta_path(args: dict) -> dict:
    design_dir = REPO_ROOT / "pipeline" / "designs" / args["design"]
    run_dir = design_dir / "runs" / args["tag"]
    return sta_path.trace(design_dir, run_dir, args["pin"],
                          corner=args.get("corner", "tt_025C_1v80"))


def _tool_sta_query(args: dict) -> dict:
    design_dir = REPO_ROOT / "pipeline" / "designs" / args["design"]
    run_dir = design_dir / "runs" / args["tag"]
    return sta_path.query(design_dir, run_dir, args["tcl"],
                          corner=args.get("corner", "tt_025C_1v80"))


def _tool_odb_query(args: dict) -> dict:
    run_dir = REPO_ROOT / "pipeline" / "designs" / args["design"] / "runs" / args["tag"]
    data = odb_query.query(run_dir)
    pattern = args.get("net_filter")
    if pattern:
        rx = re.compile(pattern)
        data["nets"] = [n for n in data["nets"] if rx.search(n["net"])]
    return data


def _tool_tech_compare(args: dict) -> dict:
    design_dir = REPO_ROOT / "pipeline" / "designs" / args["design"]
    run_spec_path = design_dir / "run_spec.json"
    targets = {}
    if run_spec_path.exists():
        targets = json.loads(run_spec_path.read_text(encoding="utf-8")).get("targets", {})
    report = tech_compare.compare(design_dir, args["variants"], targets)
    report["report_file"] = str(tech_compare.write_report(report))
    return report


def _tool_custom_status(args: dict) -> dict:
    return custom_bridge.status(docker=bool(args.get("docker"))).to_dict()


def _tool_custom_eval(args: dict) -> dict:
    return custom_bridge.evaluate(args["backend"], args["code"],
                                  timeout=int(args.get("timeout", 120))).to_dict()


def _tool_netlist_schematic(args: dict) -> dict:
    sch = Path(args["schematic"])
    if not sch.is_absolute():
        sch = REPO_ROOT / sch
    out = args.get("out_dir")
    return custom_bridge.netlist_schematic(
        sch, pdk=args.get("pdk", "sky130A"),
        out_dir=(REPO_ROOT / out if out and not Path(out).is_absolute() else out),
        timeout=int(args.get("timeout", 300))).to_dict()


def _tool_analog_loop(args: dict) -> dict:
    run = analog_loop.loop(args["design"], args.get("max_iterations"))
    path = analog_loop.write_case(run)
    return {"design": run["design"], "stop_reason": run["stop_reason"],
            "winner": run["winner"], "iterations": run["iterations"],
            "case": str(path.relative_to(REPO_ROOT))}


def _tool_analog_scan(args: dict) -> dict:
    return analog_loop.scan(args.get("design"))


def _tool_gate_schematic(args: dict) -> dict:
    run_dir = args.get("run_dir")
    resolved = (REPO_ROOT / run_dir if run_dir and not Path(run_dir).is_absolute()
                else (Path(run_dir) if run_dir else None))
    if args.get("seed"):
        out = gate_schematic.convert_cone(args["design"], args["seed"],
                                          int(args.get("depth", 4)),
                                          args.get("direction", "fanin"),
                                          run_dir=resolved)
    else:
        out = gate_schematic.convert(args["design"], run_dir=resolved)
    if out["ok"] and args.get("draw") and (out["drawable"] or args.get("force")):
        drawn = custom_bridge.render_schematic(REPO_ROOT / out["schematic"])
        out["svg"] = drawn.metadata.get("svg")
        out["_path"] = out["svg"]
    return out


def _tool_stdcell_schematic(args: dict) -> dict:
    if not args.get("cell"):
        found = stdcell_schematic.cells(args.get("q") or None)
        return {"cells": [{"cell": c, "drawable": stdcell_schematic.drawable(c)}
                          for c in found[:200]], "total": len(found)}
    out = stdcell_schematic.convert(args["cell"])
    if out["ok"] and args.get("draw"):
        drawn = custom_bridge.render_schematic(REPO_ROOT / out["schematic"])
        out["svg"] = drawn.metadata.get("svg")
        out["_path"] = out["svg"]
    return out


def _tool_stdcell_signoff(args: dict) -> dict:
    if not args.get("cell"):
        return stdcell_signoff.scan()
    result = stdcell_signoff.signoff(args["cell"])
    if result.get("ok") and not args.get("no_case"):
        result["case"] = str(stdcell_signoff.write_case(result)
                             .relative_to(REPO_ROOT))
    # The extraction is large and the case keeps it; the tool result does
    # not need to carry a netlist into a transcript.
    result.pop("layout_netlist", None)
    return result


def _tool_stdcell_survey(args: dict) -> dict:
    return stdcell_survey.survey()


def _tool_render_schematic(args: dict) -> dict:
    sch = Path(args["schematic"])
    if not sch.is_absolute():
        sch = REPO_ROOT / sch
    out = args.get("out")
    r = custom_bridge.render_schematic(
        sch, pdk=args.get("pdk", "sky130A"),
        out=(REPO_ROOT / out if out and not Path(out).is_absolute() else out),
        timeout=int(args.get("timeout", 300))).to_dict()
    # `_path` is what _content() looks for to attach an image; SVG is not
    # in _IMAGE_MIME (MCP image content is raster), so the path is what a
    # caller gets, same as any other file result.
    r["_path"] = r["metadata"].get("svg")
    return r


def _tool_spice_sim(args: dict) -> dict:
    netlist = Path(args["netlist"])
    if not netlist.is_absolute():
        netlist = REPO_ROOT / netlist
    return custom_bridge.run_spice(netlist, pdk=args.get("pdk", "sky130A"),
                                   corner=args.get("corner", "tt"),
                                   timeout=int(args.get("timeout", 300))).to_dict()


_TOOL_IMPL = {
    "ppa_run_stage": _tool_run_stage,
    "ppa_orchestrate": _tool_orchestrate,
    "ppa_get_case": _tool_get_case,
    "ppa_self_improve_scan": _tool_self_improve_scan,
    "ppa_request_review": _tool_request_review,
    "ppa_apply_review": _tool_apply_review,
    "ppa_render_layout": _tool_render_layout,
    "ppa_verify_diagnosis": _tool_verify_diagnosis,
    "ppa_equiv_check": _tool_equiv_check,
    "ppa_sta_report": _tool_sta_report,
    "ppa_sta_path": _tool_sta_path,
    "ppa_sta_query": _tool_sta_query,
    "ppa_odb_query": _tool_odb_query,
    "ppa_tech_compare": _tool_tech_compare,
    "ppa_custom_status": _tool_custom_status,
    "ppa_custom_eval": _tool_custom_eval,
    "ppa_netlist_schematic": _tool_netlist_schematic,
    "ppa_analog_loop": _tool_analog_loop,
    "ppa_analog_scan": _tool_analog_scan,
    "ppa_gate_schematic": _tool_gate_schematic,
    "ppa_stdcell_schematic": _tool_stdcell_schematic,
    "ppa_stdcell_signoff": _tool_stdcell_signoff,
    "ppa_stdcell_survey": _tool_stdcell_survey,
    "ppa_render_schematic": _tool_render_schematic,
    "ppa_spice_sim": _tool_spice_sim,
}


def _send(obj: dict) -> None:
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def _result(rid, result: dict) -> None:
    _send({"jsonrpc": "2.0", "id": rid, "result": result})


def _error(rid, code: int, msg: str) -> None:
    _send({"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": msg}})


def handle(msg: dict) -> None:
    method = msg.get("method")
    rid = msg.get("id")
    if method == "initialize":
        _result(rid, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "ppa-eda-agent-pipeline", "version": "0.1.0"},
        })
    elif method == "ping":
        _result(rid, {})
    elif method in ("notifications/initialized", "notifications/cancelled"):
        pass
    elif method == "tools/list":
        _result(rid, {"tools": TOOLS})
    elif method == "tools/call":
        params = msg.get("params", {})
        name = params.get("name")
        args = params.get("arguments", {}) or {}
        impl = _TOOL_IMPL.get(name)
        if impl is None:
            _error(rid, -32602, f"unknown tool {name}")
            return
        try:
            out = impl(args)
            _result(rid, {"content": _content(out)})
        except Exception as e:  # surface real errors to the caller, not a crash
            _error(rid, -32000, f"{name} failed: {e}")
    elif rid is not None:
        _error(rid, -32601, f"method not found: {method}")


# MCP carries images as content, and every result here was forced to
# type "text". ppa_render_layout therefore returned a filesystem path
# and nothing else — a tool whose own description cites the measured
# finding that a layout image improves diagnosis, handing the agent a
# string it cannot look at. Pattern noticed by reading
# github.com/The-OpenROAD-Project/OpenROAD-MCP, which exposes
# read_report_image for exactly this.
#
# A path is still returned alongside, because it is what a human or a
# later Bash call needs.
_IMAGE_MIME = {".png": "image/png", ".jpg": "image/jpeg",
               ".jpeg": "image/jpeg", ".gif": "image/gif"}

# Big enough for a layout render, small enough not to bury a transcript.
MAX_INLINE_IMAGE_BYTES = 4 * 1024 * 1024


def _content(out: dict) -> list[dict]:
    """A tool result as MCP content, with any image actually attached."""
    # ensure_ascii=False: this text is read by a human and pasted into a
    # later Bash call (see the _path handling below), not transported as
    # wire-protocol JSON -- \uXXXX-escaping a real path (e.g. one under a
    # non-ASCII username) makes it unreadable and unusable as a path.
    blocks = [{"type": "text",
               "text": json.dumps(out, indent=2, default=str, ensure_ascii=False)}]
    if not isinstance(out, dict):
        return blocks
    for key, value in out.items():
        if not key.endswith("_path") or not isinstance(value, str):
            continue
        path = Path(value)
        mime = _IMAGE_MIME.get(path.suffix.lower())
        if mime is None or not path.is_file():
            continue
        # Reported rather than silently dropped: an agent that asked for
        # a picture and got only a path should be told why.
        if path.stat().st_size > MAX_INLINE_IMAGE_BYTES:
            blocks.append({"type": "text",
                           "text": f"({path.name} is "
                                   f"{path.stat().st_size // 1024} KB, over the "
                                   f"{MAX_INLINE_IMAGE_BYTES // 1024} KB inline "
                                   f"limit — read it from the path above)"})
            continue
        blocks.append({"type": "image",
                       "data": base64.b64encode(path.read_bytes()).decode(),
                       "mimeType": mime})
    return blocks


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        handle(msg)


if __name__ == "__main__":
    main()
