#!/usr/bin/env python3
r"""Where a macro's slew ceiling comes from, and what would move it.

sram_wrapper has never closed. Every run dies the same way:

    [RSZ-0090] Max transition time from SDC is 0.040ns.
               Best achievable transition time is 0.043ns with a load of 0.01pF

This project already established that the 0.040ns is the macro's own
liberty pin attribute rather than an SDC value, that no config override
reaches it, and — in the commit that cut the worst address slew from
0.88ns to 0.209ns — that the remaining gap is 5.2x. What was missing is
where the number comes from. It is arithmetic anyone can check:

    OpenRAM default slew_scales      [0.25, 1, 8]
    sky130 tech.spice["rise_time"]   0.005 ns
    product                          [0.00125, 0.005, 0.04]
    the macro's own index_1          "0.00125, 0.005, 0.04"

So 0.04 ns is not a limit the SRAM imposes on the design. It is the top
of the input-slew axis the macro was characterised over. The table stops
there and `max_transition` records where it stopped; nothing was ever
measured above it. OpenSTA is not refusing a slew the memory cannot
take — it is refusing to read off the end of a table.

WHY THE CHEAP EDIT IS NOT THE FIX. sram_wrapper carries a
`.relaxed.lib` that raises the attribute from 0.04 to 0.05 without
adding a single measured point, which asks the timer to trust numbers
nobody produced. It is also not enough: this design's best measured slew
is 0.209 ns, over four times that.

WHAT WOULD FIX IT. Characterise the macro over the slew range it will
actually see. OpenRAM (github.com/VLSIDA/OpenRAM, BSD-3, the generator
these macros come from) exposes exactly that as `slew_scales` in its
SRAM config, and the sky130 macros are regenerable from
github.com/VLSIDA/sky130_sram_macros — whose copy of this liberty is
byte-identical to the PDK's on these numbers, so this is not a stale
local file.

WHAT THIS MODULE DOES NOT DO. It does not run OpenRAM. Regenerating a
macro is a SPICE characterisation sweep measured in hours and it
produces a new GDS/LEF/lib set that has to be verified before anything
trusts it. This reports what the ceiling is, where it came from, how far
past it a design actually runs, and the `slew_scales` that would cover
it — so the decision is made against numbers rather than a guess.

Usage:
    recharacterise.py <liberty> [--worst-slew-ns N]
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

import model_validity

# OpenRAM's defaults when a config sets nothing (compiler/globals.py).
OPENRAM_DEFAULT_SLEW_SCALES = [0.25, 1, 8]

# sky130's own reference rise time (technology/sky130/tech/tech.py,
# spice["rise_time"], nanoseconds). slews = slew_scales * rise_time.
SKY130_RISE_TIME_NS = 0.005

# Headroom on the top scale. A grid whose last point sits exactly on the
# worst observed slew leaves the timer interpolating to the very edge
# again the moment placement moves, which is the position this design is
# already in.
TOP_MARGIN = 1.15


def slew_scales_for(worst_slew_ns: float,
                    rise_time_ns: float = SKY130_RISE_TIME_NS) -> list[float]:
    """A slew_scales grid that covers `worst_slew_ns`, extending the default.

    Extends rather than replaces: the existing points are real
    measurements, and dropping them would discard characterisation that
    exists to add characterisation that does not. Returns the default
    unchanged when the observed slew already sits inside it — there is
    nothing to gain from a wider sweep that costs hours.
    """
    if not math.isfinite(worst_slew_ns) or worst_slew_ns < 0:
        raise ValueError("worst_slew_ns must be finite and nonnegative")
    if not math.isfinite(rise_time_ns) or rise_time_ns <= 0:
        raise ValueError("rise_time_ns must be finite and positive")
    scales = list(OPENRAM_DEFAULT_SLEW_SCALES)
    covered = max(scales) * rise_time_ns
    if worst_slew_ns <= covered:
        return scales
    needed = (worst_slew_ns * TOP_MARGIN) / rise_time_ns
    scales.append(math.ceil(needed))
    return sorted(set(scales))


def keeps_original_points(scales: list[float]) -> bool:
    """Whether a proposed grid still contains OpenRAM's default points.

    A wider grid that dropped them would reach the target slew by
    discarding characterisation that already exists — a regression
    wearing the shape of a fix.
    """
    return all(p in scales for p in OPENRAM_DEFAULT_SLEW_SCALES)


def verify_regenerated(lib_path: Path | str, target_slew_ns: float,
                       rise_time_ns: float = SKY130_RISE_TIME_NS) -> dict:
    """Check the OpenRAM input grid and explicit transition limits.

    The acceptance check for a regenerated macro, written before the
    regeneration so the bar is set in advance. Conditions are
    read out of the file rather than taken on trust:

      * its characterisation reaches `target_slew_ns`, and
      * `max_transition` moved with it, so the pin attribute agrees with
        the table underneath it, and
      * each grid retains the original points.

    This structural check cannot prove SPICE provenance, valid table
    values, or DRC/LVS. Passing it alone does not qualify a timing model.

    Returns every failure rather than the first, because a macro that
    fails both is a different problem from one that fails one.
    """
    if not math.isfinite(target_slew_ns) or target_slew_ns <= 0:
        raise ValueError("target_slew_ns must be finite and positive")
    if not math.isfinite(rise_time_ns) or rise_time_ns <= 0:
        raise ValueError("rise_time_ns must be finite and positive")
    failures = []
    ceiling = model_validity.characterisation_ceiling(lib_path)
    if ceiling is None:
        failures.append("no index_1: this file states no characterisation "
                        "ceiling at all")
        return {"ok": False, "ceiling_ns": None, "failures": failures}

    if ceiling < target_slew_ns:
        failures.append(
            f"ceiling {ceiling}ns is below the target {target_slew_ns}ns — "
            f"the grid does not reach the slew this design produces")

    text = Path(lib_path).read_text(errors="ignore")
    # Check every grid, not just the largest endpoint in the file. One
    # extended table must not hide a stale table or dropped source points.
    original = [s * rise_time_ns for s in OPENRAM_DEFAULT_SLEW_SCALES]
    for number, match in enumerate(model_validity._INDEX_1.finditer(text), 1):
        try:
            grid = [float(v.strip()) for v in match.group(1).split(",")]
        except ValueError:
            failures.append(f"index_1 grid {number} is malformed")
            continue
        if (not grid or any(not math.isfinite(v) or v <= 0 for v in grid)
                or any(a >= b for a, b in zip(grid, grid[1:]))):
            failures.append(f"index_1 grid {number} must be finite, positive and increasing")
            continue
        if grid[-1] < target_slew_ns:
            failures.append(f"index_1 grid {number} does not reach the target")
        missing = [p for p in original
                   if not any(math.isclose(p, v, rel_tol=1e-9) for v in grid)]
        if missing:
            failures.append(f"index_1 grid {number} dropped original points {missing}")
    declared = {float(v) for v in re.findall(
        r"\bmax_transition\s*:\s*([\d.eE+-]+)\s*;", text)}
    if not declared:
        failures.append("no explicit max_transition pin limits")
    # The pin attribute records where characterisation stopped. If the
    # table grew and the attribute did not, the timer still refuses the
    # slew and nothing was gained.
    stale = {d for d in declared if d < target_slew_ns}
    if stale:
        failures.append(
            f"max_transition still declares {sorted(stale)} below the target "
            f"— the attribute did not move with the table")

    return {"ok": not failures, "ceiling_ns": ceiling,
            "target_slew_ns": target_slew_ns, "failures": failures}


def analyse(lib_path: Path | str, worst_slew_ns: float | None = None,
            rise_time_ns: float = SKY130_RISE_TIME_NS) -> dict:
    """What this liberty's ceiling is, and whether a design clears it."""
    ceiling = model_validity.characterisation_ceiling(lib_path)
    if ceiling is None:
        return {"lib": str(lib_path), "ceiling_ns": None,
                "ceiling_source": "no index_1 in file",
                "needs_recharacterisation": False, "notes": [
                    "This file declares no input-slew axis, so it states no "
                    "characterisation ceiling. That is a fact about the file, "
                    "not a ceiling of zero."]}

    expected = max(OPENRAM_DEFAULT_SLEW_SCALES) * rise_time_ns
    source = ("openram_default_slew_scales"
              if abs(ceiling - expected) < 1e-9 else "custom")

    notes = []
    if source == "openram_default_slew_scales":
        notes.append(
            f"The ceiling is OpenRAM's default slew_scales "
            f"{OPENRAM_DEFAULT_SLEW_SCALES} times sky130's rise_time "
            f"{rise_time_ns}ns. It records where characterisation stopped, "
            f"not a limit the macro imposes.")
    else:
        notes.append(
            "The ceiling does not match OpenRAM's defaults, so this macro "
            "was characterised with settings of its own — read them before "
            "assuming the grid can be widened.")

    report = {
        "lib": str(lib_path),
        "ceiling_ns": ceiling,
        "ceiling_source": source,
        "needs_recharacterisation": False,
        "notes": notes,
    }

    if worst_slew_ns is None:
        notes.append(
            "No observed slew given, so whether a design clears this ceiling "
            "is unknown. Pass --worst-slew-ns from a real run.")
        return report

    report["worst_slew_ns"] = worst_slew_ns
    report["over_ceiling_x"] = worst_slew_ns / ceiling
    report["needs_recharacterisation"] = worst_slew_ns > ceiling
    # Raising the attribute without adding measured points is
    # extrapolation whatever value is chosen; it is additionally useless
    # here, because the observed slew is far past any plausible edit.
    report["relaxing_is_sufficient"] = False

    if report["needs_recharacterisation"]:
        scales = slew_scales_for(worst_slew_ns, rise_time_ns)
        report["suggested_slew_scales"] = scales
        report["suggested_grid_ns"] = [round(s * rise_time_ns, 6)
                                       for s in scales]
        notes.append(
            f"The design runs at {worst_slew_ns}ns, "
            f"{report['over_ceiling_x']:.1f}x the ceiling. Every timing "
            f"number the tool reports for these pins is extrapolated off the "
            f"end of the table.")
        notes.append(
            f"Raising max_transition in the .lib is extrapolation, not a "
            f"fix: it adds no measured point. Characterising with "
            f"slew_scales={scales} (OpenRAM config) would put the observed "
            f"slew inside the grid.")
        notes.append(
            "Regenerating is a SPICE sweep of hours and yields a new "
            "GDS/LEF/lib set that must be verified before anything trusts "
            "it. This module reports; it does not run OpenRAM.")
    else:
        notes.append(
            f"The design's worst slew {worst_slew_ns}ns sits inside the "
            f"characterised grid. Nothing here needs regenerating.")

    return report


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("liberty", help="path to a macro .lib")
    ap.add_argument("--worst-slew-ns", type=float, default=None,
                    help="worst input slew a real run produced, in ns")
    args = ap.parse_args()
    print(json.dumps(analyse(args.liberty, args.worst_slew_ns), indent=2))


if __name__ == "__main__":
    sys.exit(main())


# --- Why a learned model does not close this -------------------------
#
# Asked whether RL or a surrogate could close sram_wrapper, three real
# projects were checked rather than recalled:
#
#   google-research/circuit_training (Apache-2.0, 1.7k stars, pushed
#     2026-02-11) places "netlists with hundreds of macros and millions
#     of stdcells". sram_wrapper has one macro instance and 72 sequential
#     elements. Its premise is not this design.
#
#   circuitnet/CircuitNet (BSD-3, 506 stars, pushed 2026-05-17) predicts
#     congestion, DRC, IR-drop and net delay from LEF/DEF. Its datasets
#     are N28, N14 and N45; there is no sky130 data and no macro-pin slew
#     target. Using it here would mean building the dataset first, which
#     is the work, not the shortcut.
#
#   TILOS-AI-Institute/MacroPlacement (BSD-3, 348 stars) is benchmarks
#     and reproductions for macro placement quality, not a slew model.
#
# The deeper reason is in this file: 0.04ns is where the macro's timing
# table stops. A model that predicted slew perfectly would predict a
# violation of a limit that exists because nobody measured above it.
# Predicting the number better does not create the measurement.
#
# And there is nothing to train on. Of 406 recorded configurations three
# are macro designs and none passed, so a classifier's best strategy is
# to predict "fails" always — right every time, useless every time.
# tests/test_learned_model_fit.py pins both facts.
#
# Where a learned model does have a claim here is the cheaper question,
# which candidates are worth running, and surrogate.py already answers
# it: 99% of folds on area and 98% on power, against 65% on pass/fail.
# The weak one is the one a search would need.
